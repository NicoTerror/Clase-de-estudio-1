//Nicolas Rafael Terriquez Rodriguez
//Caso de estudio 1
//Seminario de ingenirieria en software
//21 de octubre del 2021
//Tienda de libros.
/*	*/
#include <iostream>
#include "sqlite/sqlite3.h"
#include "Libro.h"
#include <string.h>
using namespace std;
int base_datosadd(Libro libro);
static int callback(void* NotUsed, int argc, char** argv, char** azColName) {
	int i;
	for (i = 0; i < argc; i++) {
		printf("%s = %s\n", azColName[i], argv[i] ? argv[i] : "NULL");
	}
	printf("\n");
	return 0;
}
int main()
{

	Libro libro;
	base_datosadd(libro);
	cout << "Funciona!\n";
}



int base_datosadd (Libro libro)
{
	sqlite3* db;
	char* zErrMsg = 0;
	int rc;
	const char* sql;
	rc = sqlite3_open("Libreria.db", &db);
	if (rc) {
		cout << "No se puede abrir la base de datos: %s" << sqlite3_errmsg(db);
		return(0);
	}
	else {
		cout << "Base de datos abierta" << endl;
	}

	sql = "CREATE TABLE LIBRERIA("\
		"ID INT PRIMARY KEY   NOT NULL,"\
		"NAME TEXT NOT NULL,"\
		"EDITORIAL TEXT NOT NULL,"\
		"PRECIO INT NOT NULL,"\
		"STOCK INT NOT NULL,"\
		"GENERO TEXT NOT NULL;";
	if (rc != SQLITE_OK) {
		cout << "No se pudo ingresar a la base de datos" << endl;
		system("clear");
	}
	else {
		sql = "INSERT INTO LIBROS(ID,NAME,EDITORIAL,PRECIO,STOCK,GENERO) VALUES('" + libro.getID(),+"','" +libro.getNombre() +"','"+libro.getEditorial(),+"','"+libro.getPrecio(),+"','"+libro.getEjemplares(),+"','"+libro.getCategoria()+ "');";
	}

		/* Create SQL statement */
	sql = "SELECT * from LIBRERIA";
	rc = sqlite3_exec(db, sql, callback, 0, &zErrMsg);
	if (rc != SQLITE_OK) {
		cout << "SQL error: %s" << zErrMsg << endl;
		sqlite3_free(zErrMsg);
	}
	else
	{
		cout << "Datos dentro" << endl;
	}
	sqlite3_close(db);

}