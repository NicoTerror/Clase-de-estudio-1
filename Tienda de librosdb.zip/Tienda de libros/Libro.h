#pragma once

#include <iostream>
#include <string.h>
#include <sstream>
using namespace std;
class Libro
{
private:
	int ID;
	string nombreLibro;
	string editorial;
	string categoria;
	int ejemplaresLibro = 0;
	int precio;


public:
	Libro();
	Libro(string nombreLibro,string editorial, string categoria, int ejemplaresLibro, int precio, int sbn);
	string getNombre() const;
	void setNombre(const string& nombre);
	string getEditorial() const;
	void setEditorial(string& d);
	string getCategoria() const;
	void setCagetoria(string& cat);
	int getEjemplares() const;
	void setEjemplares(int ejemplares);
	int getPrecio() const;
	void setPrecio(int valor);
	void setID(const int sbn);
	int getID() const;
	string toString();
};

