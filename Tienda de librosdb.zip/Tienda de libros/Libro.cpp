#include "Libro.h"

Libro::Libro()
{
	precio = 0;
	ejemplaresLibro = 0;
}

Libro::Libro(string nombreLibro, string editorial, string categoria, int ejemplaresLibro, int precio, int ID)
{
	this->nombreLibro = nombreLibro;
	this->editorial = editorial;
	this->categoria = categoria;
	this->ejemplaresLibro = ejemplaresLibro;
	this->precio = precio;
	this->ID = ID;

}

string Libro::getNombre() const
{
	return nombreLibro;
}

void Libro::setNombre(const string& nombre)
{
	nombreLibro = nombre;
}

string Libro::getEditorial() const
{
	return editorial;
}

void Libro::setEditorial(string& d)
{
	editorial = d;
}

string Libro::getCategoria() const
{
	return categoria;
}

void Libro::setCagetoria(string& cat)
{
	categoria = cat;
}

int Libro::getEjemplares() const
{
	return ejemplaresLibro;
}

void Libro::setEjemplares(int ejemplares)
{
	ejemplaresLibro = ejemplares;
}

int Libro::getPrecio() const
{
	return precio;
}

void Libro::setPrecio(int valor)
{
	precio = valor;
}

void Libro::setID(const int sbn)
{
	ID = sbn;
}

int Libro::getID() const
{
	return ID;
}

string Libro::toString()
{
	stringstream ss;
	ss << "Nombre del libro: " << nombreLibro << "\nEditorial :" << editorial << "\nCategoria :" << categoria << "\nEjemplares : " << ejemplaresLibro << "\nPrecio :" << precio << "\nID: " << ID;
	return ss.str();
}
