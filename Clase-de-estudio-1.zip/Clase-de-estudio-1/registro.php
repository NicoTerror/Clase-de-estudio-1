<?php
//conexion servidor
$conectar=mysql_connect('localhost','Nicolas','excrementopopo13');
if(!$conectar){
echo "No se conecto con servidor"
}else
{
$base=mysql_select_db('usuarios');
if(!$base){
echo"No hay base de datos";
}
}
$correo=$_POST['Nombre'];
$contra=$_POST['ID'];
$sql="INSERT INTO users VALUES ('ID','Nombre')";
$ejecutar=mysql_query($sql);
if(!$ejecutar){
echo "Hubo algun error";
}else{
echo "Datos guardados<br><a href='Tienda de libros.html'>Volver</a>"
}
?>